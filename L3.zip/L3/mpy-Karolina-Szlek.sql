-- Karolina Szlęk, grupa MPY

-- Zadanie 1

CREATE VIEW ranking(DisplayName, liczba_odpowiedzi) AS SELECT displayname, COUNT(*) FROM users 
JOIN (SELECT A.id, A.owneruserid 
	FROM posts A 
	JOIN posts B ON (B.acceptedanswerid = A.id)) p ON (users.id=p.owneruserid) 
GROUP BY 1 
ORDER BY count DESC, 
displayname;


-- Zadanie 2

SELECT Id,DisplayName,Reputation
FROM users
WHERE users.Id NOT IN (
	SELECT UserId 
	FROM badges
	WHERE badges.Name = 'Enlightened')
AND users.UpVotes > (SELECT AVG(Enlightened.UpVotes)
	FROM (SELECT DISTINCT users.Id,users.UpVotes
	FROM users JOIN badges ON users.Id=badges.UserId
	WHERE badges.Name='Enlightened')AS Enlightened)
AND users.Id IN(SELECT X.UserId
	FROM( SELECT comments.UserId, COUNT(comments.Id)
	FROM comments
	WHERE EXTRACT(year FROM comments.CreationDate ) = 2020
	GROUP BY comments.UserId
	HAVING COUNT(comments.Id) > 1) AS X)
ORDER BY CreationDate;


-- Zadanie 3

WITH RECURSIVE reccurence AS 
(SELECT users.id, users.displayname 
	FROM users 
	JOIN (SELECT * FROM posts WHERE body LIKE '%recurrence%') p ON (users.id=p.ownerUserId) 
	UNION SELECT users.id, users.displayname 
		FROM users 
			JOIN (SELECT comments.userId AS cid FROM comments 
			JOIN (SELECT posts.id 
			FROM posts 
				JOIN reccurence ON (posts.ownerUserid=reccurence.id)) p ON (comments.postId=p.id)) c ON (users.id=c.cid)) SELECT * FROM reccurence;


